import {bootstrap}    from '@angular/platform-browser-dynamic';
import {App} from './app.component';

bootstrap(App);
